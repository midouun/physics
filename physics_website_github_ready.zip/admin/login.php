<?php
include '../init.php';

// Check if already logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

// Brute-force protection check
$time_since_last_attempt = time() - $_SESSION['last_login_attempt_time'];
if ($_SESSION['login_attempts'] >= MAX_LOGIN_ATTEMPTS && $time_since_last_attempt < LOGIN_COOLDOWN_TIME) {
    $error = sprintf($lang['too_many_login_attempts'], LOGIN_COOLDOWN_TIME - $time_since_last_attempt);
} else {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $_SESSION['last_login_attempt_time'] = time(); // Update last attempt time

        $username_input = $_POST['username'];
        $password_input = $_POST['password'];

        if ($username_input === ADMIN_USERNAME && $password_input === ADMIN_PASSWORD) {
            // Successful login
            $_SESSION['loggedin'] = true;
            $_SESSION['login_attempts'] = 0; // Reset attempts on success
            $_SESSION['last_login_attempt_time'] = 0;
            header('Location: dashboard.php');
            exit;
        } else {
            // Failed login
            $_SESSION['login_attempts']++;
            $error = $lang['invalid_credentials'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="<?php echo $_SESSION['lang']; ?>" dir="<?php echo $dir; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang['admin_login']; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="../index.php"><?php echo $lang['home']; ?></a></li>
                <li><a href="../about.php"><?php echo $lang['about']; ?></a></li>
                <li><a href="../schedule.php"><?php echo $lang['schedule']; ?></a></li>
                <li><a href="../lessons.php"><?php echo $lang['lessons']; ?></a></li>
                <li><a href="../contact.php"><?php echo $lang['contact']; ?></a></li>
                <li><a href="login.php"><?php echo $lang['admin']; ?></a></li>
            </ul>
            <div class="lang-switcher">
                <form action="" method="get" style="display:inline;">
                    <select name="lang" onchange="this.form.submit()">
                        <option value="en" <?php echo ($_SESSION['lang'] === 'en') ? 'selected' : ''; ?>><?php echo $lang['english_lang_name']; ?></option>
                        <option value="ar" <?php echo ($_SESSION['lang'] === 'ar') ? 'selected' : ''; ?>><?php echo $lang['arabic_lang_name']; ?></option>
                    </select>
                </form>
            </div>
        </nav>
    </header>
    <main>
        <section id="login">
            <h2><?php echo $lang['admin_login']; ?></h2>
            <form action="login.php" method="post">
                <div>
                    <label for="username"><?php echo $lang['username']; ?></label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div>
                    <label for="password"><?php echo $lang['password']; ?></label>
                    <input type="password" id="password" name="password" required>
                </div>
                <?php if ($error): ?>
                    <p class="error" style="color: red;"><?php echo $error; ?></p>
                <?php endif; ?>
                <button type="submit"><?php echo $lang['login']; ?></button>
            </form>
        </section>
    </main>
</body>
</html>