<?php
include '../init.php';

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}

$status_data = [
    'status_type' => '',
    'is_online' => false,
    'start_time' => '',
    'end_time' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF Protection Check
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        error_log("CSRF token mismatch on update_status.php");
        // Redirect back to dashboard with an error, or display an error message
        header('Location: dashboard.php?error=csrf');
        exit;
    }

    $status_type = $_POST['status_type'];

    if ($status_type === 'manual') {
        $status_data['status_type'] = 'manual';
        $status_data['is_online'] = ($_POST['manual_status'] === 'online');
    } elseif ($status_type === 'scheduled') {
        $status_data['status_type'] = 'scheduled';
        $status_data['start_time'] = htmlspecialchars(trim($_POST['start_time']));
        $status_data['end_time'] = htmlspecialchars(trim($_POST['end_time']));
    }

    if (file_put_contents('status.json', json_encode($status_data)) === false) {
        error_log("Failed to write status.json");
        // Handle error, e.g., redirect with an error message
        header('Location: dashboard.php?error=save_status');
    }

    // Regenerate CSRF token after form submission
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

header('Location: dashboard.php');
exit;