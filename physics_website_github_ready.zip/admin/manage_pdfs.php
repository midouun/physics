<?php
include '../init.php';

// Access Control
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}

$message = '';
$upload_dir = PDF_UPLOAD_DIR;

// Ensure upload directory exists and is writable
if (!is_dir($upload_dir)) {
    if (!mkdir($upload_dir, 0755, true)) {
        $message = $lang['error_upload_directory_not_writable'];
        error_log("Failed to create upload directory: " . $upload_dir);
    }
}
if (!is_writable($upload_dir)) {
    $message = $lang['error_upload_directory_not_writable'];
    error_log("Upload directory not writable: " . $upload_dir);
}

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_pdf'])) {
    // CSRF Protection Check
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $message = $lang['error_invalid_csrf_token'];
        error_log("CSRF token mismatch on manage_pdfs.php upload");
    } else if (isset($_FILES['pdf_file']) && $_FILES['pdf_file']['error'] === UPLOAD_ERR_OK) {
        $file_tmp_path = $_FILES['pdf_file']['tmp_name'];
        $file_name = basename($_FILES['pdf_file']['name']);
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_ext = ['pdf'];
        $max_file_size_mb = 10;

        if (!in_array($file_ext, $allowed_ext)) {
            $message = $lang['error_only_pdf_allowed'];
        } else if ($_FILES['pdf_file']['size'] > $max_file_size_mb * 1024 * 1024) { // Max 10MB
            $message = sprintf($lang['error_file_size_exceeds'], $max_file_size_mb);
        } else {
            $new_file_name = uniqid() . '.' . $file_ext; // Generate unique name
            $dest_path = $upload_dir . $new_file_name;

            if (move_uploaded_file($file_tmp_path, $dest_path)) {
                $message = $lang['file_uploaded_success'];
            } else {
                $message = $lang['error_failed_to_move_uploaded_file'];
                error_log("Failed to move uploaded file to: " . $dest_path);
            }
        }
    } else if (isset($_FILES['pdf_file']) && $_FILES['pdf_file']['error'] !== UPLOAD_ERR_NO_FILE) {
        $message = sprintf($lang['error_during_file_upload'], $_FILES['pdf_file']['error']);
        error_log("File upload error: " . $_FILES['pdf_file']['error']);
    }
    // Regenerate CSRF token after form submission
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Handle file deletion
if (isset($_GET['delete_file'])) {
    // CSRF Protection Check for GET requests
    if (!isset($_GET['csrf_token']) || $_GET['csrf_token'] !== $_SESSION['csrf_token']) {
        error_log("CSRF token mismatch on manage_pdfs.php delete");
        $message = $lang['error_invalid_csrf_token'];
    } else {
        $file_to_delete = basename($_GET['delete_file']); // Use basename to prevent path traversal
        $file_path = $upload_dir . $file_to_delete;

        if (file_exists($file_path) && is_file($file_path)) {
            if (unlink($file_path)) {
                $message = $lang['file_deleted_success'];
            } else {
                $message = $lang['error_failed_to_delete_file'];
                error_log("Failed to delete file: " . $file_path);
            }
        } else {
            $message = $lang['error_file_not_found_or_not_file'];
        }
    }
    // Regenerate CSRF token after action
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Get list of current PDF files
$pdf_files = [];
if (is_dir($upload_dir)) {
    $files = scandir($upload_dir);
    foreach ($files as $file) {
        if ($file !== '.' && $file !== '..' && pathinfo($file, PATHINFO_EXTENSION) === 'pdf') {
            $pdf_files[] = $file;
        }
    }
}

?>

<!DOCTYPE html>
<html lang="<?php echo $_SESSION['lang']; ?>" dir="<?php echo $dir; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang['manage_downloadable_pdfs']; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .file-list ul {
            list-style: none;
            padding: 0;
        }
        .file-list li {
            background-color: #162447;
            margin-bottom: 5px;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .file-list a {
            color: #e0e0e0;
            text-decoration: none;
        }
        .file-list .delete-btn {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 3px;
        }
        .message {
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            text-align: center;
        }
        .success {
            background-color: #4CAF50;
            color: white;
        }
        .error {
            background-color: #f44336;
            color: white;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="../index.php"><?php echo $lang['home']; ?></a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
            <div class="lang-switcher">
                <form action="" method="get" style="display:inline;">
                    <select name="lang" onchange="this.form.submit()">
                        <option value="en" <?php echo ($_SESSION['lang'] === 'en') ? 'selected' : ''; ?>><?php echo $lang['english_lang_name']; ?></option>
                        <option value="ar" <?php echo ($_SESSION['lang'] === 'ar') ? 'selected' : ''; ?>><?php echo $lang['arabic_lang_name']; ?></option>
                    </select>
                </form>
            </div>
        </nav>
    </header>
    <main>
        <section id="manage-pdfs">
            <h2><?php echo $lang['manage_downloadable_pdfs']; ?></h2>
            <?php if ($message): ?>
                <p class="message <?php echo (strpos($message, 'Error') !== false) ? 'error' : 'success'; ?>">
                    <?php echo $message; ?>
                </p>
            <?php endif; ?>

            <h3><?php echo $lang['upload_new_pdf']; ?></h3>
            <form action="manage_pdfs.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div>
                    <label for="pdf_file"><?php echo $lang['select_pdf_to_upload']; ?></label>
                    <input type="file" id="pdf_file" name="pdf_file" accept=".pdf" required>
                </div>
                <button type="submit" name="upload_pdf"><?php echo $lang['upload_pdf']; ?></button>
            </form>

            <h3><?php echo $lang['existing_pdfs']; ?></h3>
            <?php if (count($pdf_files) > 0): ?>
                <div class="file-list">
                    <ul>
                        <?php foreach ($pdf_files as $file): ?>
                            <li>
                                <a href="<?php echo str_replace(__DIR__ . '/../', '', $upload_dir) . htmlspecialchars($file); ?>" target="_blank">
                                    <?php echo htmlspecialchars($file); ?>
                                </a>
                                <button class="delete-btn" onclick="if(confirm('<?php echo sprintf($lang['confirm_delete_pdf'], htmlspecialchars($file)); ?>')) { window.location.href='manage_pdfs.php?delete_file=<?php echo urlencode($file); ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>'; }">Delete</button>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php else: ?>
                <p><?php echo $lang['no_pdfs_uploaded_yet']; ?></p>
            <?php endif; ?>
        </section>
    </main>
</body>
</html>