<?php
include '../init.php';
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}

// Read current status
$status_file = 'status.json';
$current_status = ['status_type' => 'manual', 'is_online' => false, 'start_time' => '', 'end_time' => ''];
if (file_exists($status_file)) {
    $current_status = json_decode(file_get_contents($status_file), true);
}
?>

<!DOCTYPE html>
<html lang="<?php echo $_SESSION['lang']; ?>" dir="<?php echo $dir; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="../index.php"><?php echo $lang['home']; ?></a></li>
                <li><a href="../about.php"><?php echo $lang['about']; ?></a></li>
                <li><a href="../schedule.php"><?php echo $lang['schedule']; ?></a></li>
                <li><a href="../lessons.php"><?php echo $lang['lessons']; ?></a></li>
                <li><a href="../contact.php"><?php echo $lang['contact']; ?></a></li>
                <li><a href="logout.php"><?php echo $lang['logout']; ?></a></li>
            </ul>
            <div class="lang-switcher">
                <form action="" method="get" style="display:inline;">
                    <select name="lang" onchange="this.form.submit()">
                        <option value="en" <?php echo ($_SESSION['lang'] === 'en') ? 'selected' : ''; ?>><?php echo $lang['english_lang_name']; ?></option>
                        <option value="ar" <?php echo ($_SESSION['lang'] === 'ar') ? 'selected' : ''; ?>><?php echo $lang['arabic_lang_name']; ?></option>
                    </select>
                </form>
            </div>
        </nav>
    </header>
    <main>
        <section id="dashboard">
            <h2><?php echo $lang['welcome_professor']; ?></h2>
            <p><?php echo $lang['dashboard_text']; ?></p>
            
            <h3><?php echo $lang['admin_actions']; ?></h3>
            <ul>
                <li><a href="../forum/admin.php"><?php echo $lang['review_forum_posts']; ?></a></li>
                <li><a href="edit_about.php"><?php echo $lang['edit_about_section']; ?></a></li>
                <li><a href="edit_homepage.php"><?php echo $lang['edit_homepage_content']; ?></a></li>
                <li><a href="manage_pdfs.php"><?php echo $lang['manage_downloadable_pdfs']; ?></a></li>
            </ul>

            <hr style="margin: 2rem 0;">

            <h3><?php echo $lang['set_activity_status']; ?></h3>
            <form action="update_status.php" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div>
                    <input type="radio" id="manual" name="status_type" value="manual" <?php echo ($current_status['status_type'] === 'manual') ? 'checked' : ''; ?>>
                    <label for="manual"><?php echo $lang['manual_status']; ?></label>
                    <select name="manual_status" id="manual_status">
                        <option value="online" <?php echo ($current_status['is_online']) ? 'selected' : ''; ?>><?php echo $lang['online']; ?></option>
                        <option value="offline" <?php echo (!$current_status['is_online']) ? 'selected' : ''; ?>><?php echo $lang['offline']; ?></option>
                    </select>
                </div>

                <div style="margin-top: 1rem;">
                    <input type="radio" id="scheduled" name="status_type" value="scheduled" <?php echo ($current_status['status_type'] === 'scheduled') ? 'checked' : ''; ?>>
                    <label for="scheduled"><?php echo $lang['scheduled_status']; ?></label>
                    <br>
                    <label for="start_time"><?php echo $lang['from']; ?></label>
                    <input type="time" id="start_time" name="start_time" value="<?php echo $current_status['start_time']; ?>">
                    <label for="end_time"><?php echo $lang['to']; ?></label>
                    <input type="time" id="end_time" name="end_time" value="<?php echo $current_status['end_time']; ?>">
                </div>

                <button type="submit" style="margin-top: 1rem;"><?php echo $lang['save_status']; ?></button>
            </form>

        </section>
    </main>
</body>
</html>