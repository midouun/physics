<?php
// Include the initialization file which handles session start, language loading, and directory setting.
include '../init.php';

// --- Access Control: Ensure only logged-in administrators can access this page ---
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit; // Stop script execution
}

// Define the path to the file storing the 'About' section content.
// __DIR__ refers to the directory of the current script (admin/), so we go up one level (../)
// to reach the physics_website/ directory, then into content/.
$about_content_file = __DIR__ . '/../content/about_content.html';
$message = ''; // Variable to store success or error messages
$max_length = MAX_ABOUT_CONTENT_LENGTH; // Maximum allowed characters for the 'About' content

// --- Auto-creation of about_content.html if it doesn't exist ---
// This ensures the file is present on first run or if it was accidentally deleted.
if (!file_exists($about_content_file)) {
    // Attempt to write the default content to the file.
    // file_put_contents returns false on failure (e.g., permission issues).
    if (file_put_contents($about_content_file, DEFAULT_ABOUT_CONTENT) === false) {
        // Set an error message if auto-creation fails.
        $message = $lang['error_create_default_about'];
        error_log("Failed to create default about_content.html: " . $about_content_file);
    }
}

// --- Handle Form Submission (when the "Save Changes" button is clicked) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF Protection Check
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $message = $lang['error_invalid_csrf_token'];
        error_log("CSRF token mismatch on edit_about.php");
    } else {
        $new_content = trim($_POST['about_content']); // Trim whitespace

        // Validate content length to prevent excessively large inputs (DoS prevention).
        // mb_strlen is used for accurate character counting with multi-byte characters (like Arabic).
        if (mb_strlen($new_content, 'UTF-8') > $max_length) {
            // Use sprintf to insert the max_length into the translated error message.
            $message = sprintf($lang['error_content_too_long'], $max_length);
        } else {
            // Sanitize the input before saving to the file.
            // htmlspecialchars() converts HTML special characters to entities.
            // This is crucial for security: it prevents any HTML or JavaScript
            // entered by the admin from being executed when the content is displayed
            // on the public 'about.php' page. This means the 'About' section will
            // display as plain text, not rich HTML.
            // For future rich text support, a robust HTML sanitization library (e.g., HTML Purifier) is recommended.
            $new_content_sanitized = htmlspecialchars($new_content, ENT_QUOTES, 'UTF-8');

            // Attempt to write the sanitized content to the file.
            if (file_put_contents($about_content_file, $new_content_sanitized) !== false) {
                // Set a success message if the save operation is successful.
                $message = $lang['about_updated_success'];
            } else {
                // Set an error message if saving fails, likely due to file permissions.
                // Provide clear instructions for fixing permissions on a Linux system.
                $message = $lang['error_save_content'] . ' ' .
                           'Try running: sudo chown -R www-data:www-data /root/physics_website/content && ' .
                           'sudo chmod -R 755 /root/physics_website/content';
                error_log("Failed to save about_content.html: " . $about_content_file);
            }
        }
    }
    // Regenerate CSRF token after form submission
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// --- Read Current Content for Display in the Textarea ---
$current_content = ''; // Initialize variable to hold content for the textarea
if (file_exists($about_content_file)) {
    // Attempt to read the file content.
    $file_content = file_get_contents($about_content_file);

    // Check if file_get_contents was successful (returns false on failure).
    if ($file_content !== false) {
        // Decode HTML entities for display in the textarea. This is important because
        // htmlspecialchars() was used on save. We want the admin to see the actual
        // characters they typed, not their HTML entities.
        $current_content = htmlspecialchars_decode($file_content, ENT_QUOTES);
    } else {
        // Error reading the file, likely due to permissions.
        $message = $lang['error_read_about'];
        error_log("Failed to read about_content.html: " . $about_content_file);
    }
} else {
    // This case should ideally not be reached due to auto-creation, but serves as a fallback.
    $message = $lang['warning_about_not_found'];
    error_log("about_content.html not found (after auto-creation attempt): " . $about_content_file);
}

?>

<!DOCTYPE html>
<html lang="<?php echo $_SESSION['lang']; ?>" dir="<?php echo $dir; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang['edit_about_section']; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <!-- TinyMCE CDN (replace with local if preferred) -->
    <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
        tinymce.init({
            selector: '#about_content_editor',
            plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table paste code help wordcount',
            toolbar: 'undo redo | formatselect | bold italic backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
            height: 400,
            menubar: false,
            setup: function (editor) {
                editor.on('change', function () {
                    editor.save(); // Update the textarea on change
                    updateCharCount();
                });
            }
        });

        function updateCharCount() {
            const editorContent = tinymce.get('about_content_editor').getContent({ format: 'text' });
            const remaining = <?php echo MAX_ABOUT_CONTENT_LENGTH; ?> - editorContent.length;
            document.getElementById('char_count').textContent = remaining;
        }

        document.addEventListener('DOMContentLoaded', function() {
            // Initial character count after TinyMCE loads
            setTimeout(updateCharCount, 500); // Give TinyMCE a moment to initialize

            // Preview functionality
            const previewButton = document.getElementById('preview_button');
            const previewArea = document.getElementById('preview_area');

            previewButton.addEventListener('click', function(event) {
                event.preventDefault(); // Prevent form submission
                const editorContent = tinymce.get('about_content_editor').getContent(); // Get HTML content
                previewArea.innerHTML = editorContent;
                previewArea.style.display = 'block';
            });
        });
    </script>
    <style>
        /* Basic styling for the textarea and messages */
        textarea {
            width: 100%;
            height: 300px;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            background-color: #2a2a4a; /* Dark background for textarea */
            color: #e0e0e0; /* Light text color */
            box-sizing: border-box; /* Include padding and border in the element's total width and height */
            resize: vertical; /* Allow vertical resizing */
        }
        .message {
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            text-align: center;
        }
        .success {
            background-color: #4CAF50; /* Green */
            color: white;
        }
        .error {
            background-color: #f44336; /* Red */
            color: white;
        }
        #preview_area {
            background-color: #1a1a2e;
            border: 1px solid #333;
            padding: 15px;
            margin-top: 20px;
            display: none; /* Hidden by default */
            color: #e0e0e0;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="../index.php"><?php echo $lang['home']; ?></a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
            <div class="lang-switcher">
                <form action="" method="get" style="display:inline;">
                    <select name="lang" onchange="this.form.submit()">
                        <option value="en" <?php echo ($_SESSION['lang'] === 'en') ? 'selected' : ''; ?>><?php echo $lang['english_lang_name']; ?></option>
                        <option value="ar" <?php echo ($_SESSION['lang'] === 'ar') ? 'selected' : ''; ?>><?php echo $lang['arabic_lang_name']; ?></option>
                    </select>
                </form>
            </div>
        </nav>
    </header>
    <main>
        <section id="edit-about">
            <h2><?php echo $lang['edit_about_section']; ?></h2>
            <?php if ($message): ?>
                <p class="message <?php echo (strpos($message, 'Error') !== false || strpos($message, 'Warning') !== false) ? 'error' : 'success'; ?>">
                    <?php echo $message; ?>
                </p>
            <?php endif; ?>
            <form action="edit_about.php" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <textarea id="about_content_editor" name="about_content"><?php echo htmlspecialchars($current_content, ENT_QUOTES, 'UTF-8'); ?></textarea>
                <p><?php echo $lang['characters_remaining']; ?> <span id="char_count"><?php echo MAX_ABOUT_CONTENT_LENGTH - mb_strlen($current_content, 'UTF-8'); ?></span></p>
                <button type="submit"><?php echo $lang['save_changes']; ?></button>
                <button type="button" id="preview_button">Preview</button>
            </form>
            <div id="preview_area"></div>
        </section>
    </main>
</body>
</html>