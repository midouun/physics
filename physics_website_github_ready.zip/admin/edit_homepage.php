<?php
// Include the initialization file which handles session start, language loading, and directory setting.
include '../init.php';

// --- Access Control: Ensure only logged-in administrators can access this page ---
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit; // Stop script execution
}

// Define the path to the file storing the homepage content.
$homepage_content_file = __DIR__ . '/../content/homepage_content.html';
$message = ''; // Variable to store success or error messages
$max_length = MAX_ABOUT_CONTENT_LENGTH; // Using the same max length as 'About' for consistency

// --- Auto-creation of homepage_content.html if it doesn't exist ---
if (!file_exists($homepage_content_file)) {
    $default_content = "<h2>Welcome to Mr. Samahi Abdelhak's Physics Website!</h2>\n<p>This website is dedicated to providing valuable resources and information for high school physics students in Aïn El Hadjar, Saïda, Algeria.</p>\n<p>Here you will find class schedules, downloadable lessons, and a student forum to discuss physics topics.</p>\n<p>Let's explore the wonders of physics together!</p>";
    if (file_put_contents($homepage_content_file, $default_content) === false) {
        $message = $lang['error_create_default_homepage'];
        error_log("Failed to create default homepage_content.html: " . $homepage_content_file);
    }
}

// --- Handle Form Submission ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF Protection Check
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $message = $lang['error_invalid_csrf_token'];
        error_log("CSRF token mismatch on edit_homepage.php");
    } else {
        $new_content = trim($_POST['homepage_content']);

        // Validate content length
        if (mb_strlen($new_content, 'UTF-8') > $max_length) {
            $message = sprintf($lang['error_content_too_long'], $max_length);
        } else {
            // Save the content directly as HTML from TinyMCE. 
            // IMPORTANT: In a production environment, this content MUST be sanitized
            // using a robust HTML sanitization library (e.g., HTML Purifier) before saving.
            // For this exercise, we assume the admin is trusted.
            if (file_put_contents($homepage_content_file, $new_content) !== false) {
                $message = $lang['homepage_updated_success'];
            } else {
                $message = $lang['error_save_content'] . ' ' .
                           'Try running: sudo chown -R www-data:www-data /root/physics_website/content && ' .
                           'sudo chmod -R 755 /root/physics_website/content';
                error_log("Failed to save homepage_content.html: " . $homepage_content_file);
            }
        }
    }
    // Regenerate CSRF token after form submission
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// --- Read Current Content for Display in the Editor ---
$current_content = '';
if (file_exists($homepage_content_file)) {
    $file_content = file_get_contents($homepage_content_file);
    if ($file_content !== false) {
        $current_content = $file_content; // Read as raw HTML for TinyMCE
    } else {
        $message = $lang['error_read_homepage'];
        error_log("Failed to read homepage_content.html: " . $homepage_content_file);
    }
} else {
    $message = $lang['warning_homepage_not_found'];
    error_log("homepage_content.html not found (after auto-creation attempt): " . $homepage_content_file);
}

?>

<!DOCTYPE html>
<html lang="<?php echo $_SESSION['lang']; ?>" dir="<?php echo $dir; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang['edit_homepage_content']; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <!-- TinyMCE CDN -->
    <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
        tinymce.init({
            selector: '#homepage_content_editor',
            plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table paste code help wordcount',
            toolbar: 'undo redo | formatselect | bold italic backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
            height: 400,
            menubar: false,
            setup: function (editor) {
                editor.on('change', function () {
                    editor.save(); // Update the textarea on change
                    updateCharCount();
                });
            }
        });

        function updateCharCount() {
            const editorContent = tinymce.get('homepage_content_editor').getContent({ format: 'text' });
            const remaining = <?php echo MAX_ABOUT_CONTENT_LENGTH; ?> - editorContent.length;
            document.getElementById('char_count').textContent = remaining;
        }

        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(updateCharCount, 500); // Give TinyMCE a moment to initialize

            // Preview functionality
            const previewButton = document.getElementById('preview_button');
            const previewArea = document.getElementById('preview_area');

            previewButton.addEventListener('click', function(event) {
                event.preventDefault(); // Prevent form submission
                const editorContent = tinymce.get('homepage_content_editor').getContent(); // Get HTML content
                previewArea.innerHTML = editorContent;
                previewArea.style.display = 'block';
            });
        });
    </script>
    <style>
        textarea {
            width: 100%;
            height: 300px;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            background-color: #2a2a4a;
            color: #e0e0e0;
            box-sizing: border-box;
            resize: vertical;
        }
        .message {
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            text-align: center;
        }
        .success {
            background-color: #4CAF50;
            color: white;
        }
        .error {
            background-color: #f44336;
            color: white;
        }
        #preview_area {
            background-color: #1a1a2e;
            border: 1px solid #333;
            padding: 15px;
            margin-top: 20px;
            display: none;
            color: #e0e0e0;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="../index.php"><?php echo $lang['home']; ?></a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
            <div class="lang-switcher">
                <form action="" method="get" style="display:inline;">
                    <select name="lang" onchange="this.form.submit()">
                        <option value="en" <?php echo ($_SESSION['lang'] === 'en') ? 'selected' : ''; ?>><?php echo $lang['english_lang_name']; ?></option>
                        <option value="ar" <?php echo ($_SESSION['lang'] === 'ar') ? 'selected' : ''; ?>><?php echo $lang['arabic_lang_name']; ?></option>
                    </select>
                </form>
            </div>
        </nav>
    </header>
    <main>
        <section id="edit-homepage">
            <h2><?php echo $lang['edit_homepage_content']; ?></h2>
            <?php if ($message): ?>
                <p class="message <?php echo (strpos($message, 'Error') !== false || strpos($message, 'Warning') !== false) ? 'error' : 'success'; ?>">
                    <?php echo $message; ?>
                </p>
            <?php endif; ?>
            <form action="edit_homepage.php" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <textarea id="homepage_content_editor" name="homepage_content"><?php echo htmlspecialchars($current_content, ENT_QUOTES, 'UTF-8'); ?></textarea>
                <p><?php echo $lang['characters_remaining']; ?> <span id="char_count"><?php echo $max_length - mb_strlen($current_content, 'UTF-8'); ?></span></p>
                <button type="submit"><?php echo $lang['save_changes']; ?></button>
                <button type="button" id="preview_button">Preview</button>
            </form>
            <div id="preview_area"></div>
        </section>
    </main>
</body>
</html>