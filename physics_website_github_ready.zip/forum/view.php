<?php
include '../init.php';
include '../db.php'; // Include the database connection file
?>
<!DOCTYPE html>
<html lang="<?php echo $_SESSION['lang']; ?>" dir="<?php echo $dir; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang['approved_forum_posts']; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="../index.php"><?php echo $lang['home']; ?></a></li>
                <li><a href="submit.php"><?php echo $lang['submit_a_post']; ?></a></li>
            </ul>
            <div class="lang-switcher">
                <form action="" method="get" style="display:inline;">
                    <select name="lang" onchange="this.form.submit()">
                        <option value="en" <?php echo ($_SESSION['lang'] === 'en') ? 'selected' : ''; ?>><?php echo $lang['english_lang_name']; ?></option>
                        <option value="ar" <?php echo ($_SESSION['lang'] === 'ar') ? 'selected' : ''; ?>><?php echo $lang['arabic_lang_name']; ?></option>
                    </select>
                </form>
            </div>
        </nav>
    </header>
    <main>
        <section id="forum-posts">
            <h2><?php echo $lang['approved_forum_posts']; ?></h2>
            <?php
            try {
                $pdo = get_db_connection();
                $stmt = $pdo->prepare('SELECT * FROM posts WHERE approved = 1 ORDER BY date DESC');
                $stmt->execute();
                $posts = $stmt->fetchAll();

                if (count($posts) > 0) {
                    foreach ($posts as $row) {
                        echo "<div class='post'>";
                        echo "<h3>" . htmlspecialchars($row['title']) . "</h3>";
                        echo "<p><strong>" . $lang['by'] . "</strong> " . htmlspecialchars($row['name']) . " | <strong>" . $lang['class'] . "</strong> " . htmlspecialchars($row['class']) . " | <strong>" . $lang['date'] . "</strong> " . $row['date'] . "</p>";
                        echo "<p>" . nl2br(htmlspecialchars($row['body'])) . "</p>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>" . $lang['no_approved_posts_yet'] . "</p>";
                }
            } catch (PDOException $e) {
                error_log("Forum view failed: " . $e->getMessage());
                echo "<p>" . $lang['error_submitting_post'] . "</p>"; // Re-using a general error message
            }
            ?>
        </section>
    </main>
</body>
</html>