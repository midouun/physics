<?php
include '../init.php';
include '../db.php'; // Include the database connection file

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: ../admin/login.php');
    exit;
}

if (isset($_GET['id'])) {
    // CSRF Protection Check for GET requests
    if (!isset($_GET['csrf_token']) || $_GET['csrf_token'] !== $_SESSION['csrf_token']) {
        error_log("CSRF token mismatch on delete.php");
        header('Location: admin.php?error=csrf');
        exit;
    }

    $id = (int)$_GET['id'];
    
    try {
        $pdo = get_db_connection();
        $stmt = $pdo->prepare('DELETE FROM posts WHERE id = :id');
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
    } catch (PDOException $e) {
        error_log("Failed to delete post ID " . $id . ": " . $e->getMessage());
        // Redirect with an error message if needed
        header('Location: admin.php?error=delete_failed');
        exit;
    }

    // Regenerate CSRF token after action
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

header('Location: admin.php');
exit;