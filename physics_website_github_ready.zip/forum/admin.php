<?php
include '../init.php';
include '../db.php'; // Include the database connection file

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: ../admin/login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="<?php echo $_SESSION['lang']; ?>" dir="<?php echo $dir; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Review Posts</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="../index.php"><?php echo $lang['home']; ?></a></li>
                <li><a href="../admin/dashboard.php">Dashboard</a></li>
                <li><a href="../admin/logout.php">Logout</a></li>
            </ul>
            <div class="lang-switcher">
                <form action="" method="get" style="display:inline;">
                    <select name="lang" onchange="this.form.submit()">
                        <option value="en" <?php echo ($_SESSION['lang'] === 'en') ? 'selected' : ''; ?>><?php echo $lang['english_lang_name']; ?></option>
                        <option value="ar" <?php echo ($_SESSION['lang'] === 'ar') ? 'selected' : ''; ?>><?php echo $lang['arabic_lang_name']; ?></option>
                    </select>
                </form>
            </div>
        </nav>
    </header>
    <main>
        <section id="review-posts">
            <h2>Unapproved Forum Posts</h2>
            <?php
            try {
                $pdo = get_db_connection();
                $stmt = $pdo->prepare('SELECT * FROM posts WHERE approved = 0 ORDER BY date DESC');
                $stmt->execute();
                $posts = $stmt->fetchAll();

                if (count($posts) > 0) {
                    foreach ($posts as $row) {
                        echo "<div class='post'>";
                        echo "<h3>" . htmlspecialchars($row['title']) . "</h3>";
                        echo "<p><strong>By:</strong> " . htmlspecialchars($row['name']) . " | <strong>Class:</strong> " . htmlspecialchars($row['class']) . " | <strong>Date:</strong> " . $row['date'] . "</p>";
                        echo "<p>" . nl2br(htmlspecialchars($row['body'])) . "</p>";
                        // Add CSRF token to the links
                        echo "<a href='publish.php?id=" . $row['id'] . "&csrf_token=" . $_SESSION['csrf_token'] . "'>Approve</a> | <a href='delete.php?id=" . $row['id'] . "&csrf_token=" . $_SESSION['csrf_token'] . "'>Delete</a>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>No unapproved posts to review.</p>";
                }
            } catch (PDOException $e) {
                error_log("Forum admin view failed: " . $e->getMessage());
                echo "<p>An error occurred while loading posts for review. Please try again later.</p>";
            }
            ?>
        </section>
    </main>
</body>
</html>