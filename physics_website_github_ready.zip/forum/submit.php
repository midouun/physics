<?php
include '../init.php';
include '../db.php'; // Include the database connection file

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF Protection Check
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        error_log("CSRF token mismatch on forum/submit.php");
        $message = $lang['error_invalid_csrf_token'];
    } else {
        $name = htmlspecialchars(trim($_POST['name']));
        $class = htmlspecialchars(trim($_POST['class']));
        $title = htmlspecialchars(trim($_POST['title']));
        $body = htmlspecialchars(trim($_POST['body']));

        if (!empty($name) && !empty($title) && !empty($body)) {
            try {
                $pdo = get_db_connection();
                $stmt = $pdo->prepare('INSERT INTO posts (name, class, title, body) VALUES (:name, :class, :title, :body)');
                $stmt->bindParam(':name', $name);
                $stmt->bindParam(':class', $class);
                $stmt->bindParam(':title', $title);
                $stmt->bindParam(':body', $body);
                $stmt->execute();
                $message = $lang['post_submitted_for_review'];
            } catch (PDOException $e) {
                error_log("Forum post submission failed: " . $e->getMessage());
                $message = $lang['error_submitting_post'];
            }
        } else {
            $message = $lang['fill_all_required_fields'];
        }
    }
    // Regenerate CSRF token after form submission
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="<?php echo $_SESSION['lang']; ?>" dir="<?php echo $dir; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang['submit_a_post']; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="../index.php"><?php echo $lang['home']; ?></a></li>
                <li><a href="view.php"><?php echo $lang['view_forum']; ?></a></li>
            </ul>
            <div class="lang-switcher">
                <form action="" method="get" style="display:inline;">
                    <select name="lang" onchange="this.form.submit()">
                        <option value="en" <?php echo ($_SESSION['lang'] === 'en') ? 'selected' : ''; ?>><?php echo $lang['english_lang_name']; ?></option>
                        <option value="ar" <?php echo ($_SESSION['lang'] === 'ar') ? 'selected' : ''; ?>><?php echo $lang['arabic_lang_name']; ?></option>
                    </select>
                </form>
            </div>
        </nav>
    </header>
    <main>
        <section id="submit-post">
            <h2><?php echo $lang['submit_a_new_post']; ?></h2>
            <?php if ($message): ?>
                <p><?php echo $message; ?></p>
            <?php endif; ?>
            <form action="submit.php" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div>
                    <label for="name"><?php echo $lang['full_name']; ?></label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div>
                    <label for="class"><?php echo $lang['class_optional']; ?></label>
                    <input type="text" id="class" name="class">
                </div>
                <div>
                    <label for="title"><?php echo $lang['post_title']; ?></label>
                    <input type="text" id="title" name="title" required>
                </div>
                <div>
                    <label for="body"><?php echo $lang['post_body']; ?></label>
                    <textarea id="body" name="body" rows="10" required></textarea>
                </div>
                <button type="submit"><?php echo $lang['submit_post']; ?></button>
            </form>
        </section>
    </main>
</body>
</html>